# rawdata
This folder stores the original datasets.