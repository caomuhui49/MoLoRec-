pip install -r requirements.txt
git clone --depth 1 https://github.com/hiyouga/LLaMA-Factory.git --branch v0.9.1
cd LLaMA-Factory
pip install -e .