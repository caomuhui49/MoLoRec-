sh scripts/train_base.sh
sh scripts/train_beauty.sh
sh scripts/train_toys.sh
sh scripts/train_sports.sh
