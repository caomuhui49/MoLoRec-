# traindata
This folder stores the train datasets and validation datasets.